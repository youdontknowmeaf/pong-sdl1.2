// tinygettext - A gettext replacement that works directly on .po files
// Copyright (c) 2009 Ingo Ruhnke <grumbel@gmail.com>
//
// This software is provided 'as-is', without any express or implied
// warranty. In no event will the authors be held liable for any damages
// arising from the use of this software.
//
// Permission is granted to anyone to use this software for any purpose,
// including commercial applications, and to alter it and redistribute it
// freely, subject to the following restrictions:
//
// 1. The origin of this software must not be misrepresented; you must not
//    claim that you wrote the original software. If you use this software
//    in a product, an acknowledgement in the product documentation would be
//    appreciated but is not required.
// 2. Altered source versions must be plainly marked as such, and must not be
//    misrepresented as being the original software.
// 3. This notice may not be removed or altered from any source distribution.

#ifndef HEADER_TINYGETTEXT_LOG_STREAM_HPP
#define HEADER_TINYGETTEXT_LOG_STREAM_HPP

#include "log.hpp"

namespace tinygettext {

// FIXME: very bad to have such things in the API
#define log_error   if (!Log::log_error_callback);   else (Log(Log::log_error_callback)).get()
#define log_warning if (!Log::log_warning_callback); else (Log(Log::log_warning_callback)).get()
#define log_info    if (!Log::log_info_callback);    else (Log(Log::log_info_callback)).get()

} // namespace tinygettext

#endif

/* EOF */
