/*  This file is part of SAIL (https://github.com/HappySeaFox/sail)

    Copyright (c) 2020 Dmitry Baryshev

    The MIT License

    Permission is hereby granted, free of charge, to any person obtaining a copy
    of this software and associated documentation files (the "Software"), to deal
    in the Software without restriction, including without limitation the rights
    to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
    copies of the Software, and to permit persons to whom the Software is
    furnished to do so, subject to the following conditions:

    The above copyright notice and this permission notice shall be included in all
    copies or substantial portions of the Software.

    THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
    IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
    FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
    AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
    LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
    OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
    SOFTWARE.
*/

#pragma once

#include <string>

#include <sail-common/export.h>
#include <sail-common/log.h>
#include <sail-common/status.h>

namespace sail
{

/*
 * Logging functions.
 */
namespace log
{

/*
 * Converts a string representation of a log level to SailLogLevel.
 * Returns the corresponding log level on success, or SAIL_LOG_LEVEL_DEBUG on error.
 *
 * Supported strings: "silence", "error", "warning", "info", "message", "debug", "trace".
 */
SAIL_EXPORT SailLogLevel level_from_string(const char *str);

/*
 * Converts a string representation of a log level to SailLogLevel.
 * Returns the corresponding log level on success, or SAIL_LOG_LEVEL_DEBUG on error.
 *
 * Supported strings: "silence", "error", "warning", "info", "message", "debug", "trace".
 */
SAIL_EXPORT SailLogLevel level_from_string(const std::string &str);

/*
 * Sets a maximum log level barrier. Only the messages of the specified log level or lower will be displayed.
 *
 * Call to this function is not thread-safe. It's recommended to call it in the main thread
 * before initializing SAIL.
 */
SAIL_EXPORT void set_barrier(SailLogLevel max_level);

/*
 * Sets an external logger to pass all filtered log messages into.
 *
 * If the installed logger returns true, the log message is considered consumed.
 * If the installed logger returns false, the log message is passed to the default logger.
 *
 * Call to this function is not thread-safe. It's recommended to call it in the main thread
 * before initializing SAIL.
 */
SAIL_EXPORT void set_logger(sail_logger logger);

} // namespace log

} // namespace sail
